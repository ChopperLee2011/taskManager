taskManager
===========
use AngularJS and MongoLab 
module: angular-mongolab from https://github.com/pkozlowski-opensource/angularjs-mongolab 
demo:http://development.taskmagr.divshot.io/
